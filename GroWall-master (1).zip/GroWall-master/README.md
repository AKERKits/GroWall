# GroWall

The GroWall is a CNC-routable, flat-packable, wall-mounted planter box designed to be made from a single sheet of plywood.

For more information, visit: http://www.aker.me
